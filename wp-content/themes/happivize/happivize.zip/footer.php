<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */
?>
			 <footer>
                <div class="footer_top">
                    <div class="container">
                        <div class="row clearfix">
                            <div class="col-sm-4">
                               <?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar('footer1') ) : else : ?>
								<?php endif; ?>
                            </div>
                            <div class="col-sm-4">
                                <div class="links_main">
                                    <h4 class="footer_title">Quick links</h4>
                                        <?php $args = array('menu' => 'primary' , 'menu_class'  => 'quick_links clearfix', 'container' =>'' );wp_nav_menu($args); ?>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar('footer2') ) : else : ?>
								<?php endif; ?>
								
                            </div>
                        </div>
                    </div>
                </div>
                <div class="footer_bottom">
                    <div class="copyright_txt">© 2016 happivize. All rights reserved.</div>
                </div>
          </footer>
      </div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script> 
<script src="<?php echo get_template_directory_uri(); ?>/js/bootstrap.min.js"></script>	  
<?php wp_footer(); ?>
</body>
</html>
